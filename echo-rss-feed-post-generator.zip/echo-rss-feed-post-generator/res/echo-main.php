<?php
function echo_admin_settings()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('echo_option_group');
    do_settings_sections('echo_option_group');
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    if (isset($echo_Main_Settings['echo_enabled'])) {
        $echo_enabled = $echo_Main_Settings['echo_enabled'];
    } else {
        $echo_enabled = '';
    }
    
?>
<script>
                var echo_admin_json = {
                    
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
    }
    window.onload = mainChanged;
    var unsaved = false;
    jQuery(document).ready(function () {
        jQuery(":input").change(function(){
            unsaved = true;
        });
        function unloadPage(){ 
            if(unsaved){
                return "You have unsaved changes on this page. Do you want to leave this page and discard your changes or stay on this page?";
            }
        }
        window.onbeforeunload = unloadPage;
    });
</script>
<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('.echo_image_button').click(function(){
				tb_show('',"media-upload.php?type=image&TB_iframe=true");
			});
			
		});
	</script>
<?php if( isset($_GET['settings-updated']) ) 
{ 
?>
<div id=”message” class=”updated”>
<p style="border-bottom: 6px solid green;background-color: lightgrey;color:green;"><strong>&nbsp;Settings saved.</strong></p>
</div>
<?php 
}
?>
<div ng-app="echsettingsApp" ng-controller="echsettingsController" ng-cloak ng-init="initialized()">
<div class="echo_class">
<table>
    <tr>
    <td>
        <h1><span class="gs-sub-heading"><b>Echo RSS Feed Post Generator Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Echo RSS Feed Post Generator Plugin. This acts like a main switch.";
?>
                        </div>
                    </div></h1>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="echo_enabled" name="echo_Main_Settings[echo_enabled]" onChange="mainChanged()" <?php
    if ($echo_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="echo_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
            </div>
        </div>
        </div>
         <hr/>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
if (isset($_POST['echo_keyword_list'])) {
	add_action('admin_init', 'echo_save_keyword_rules');
}
function echo_save_keyword_rules($data2) {
    //todo
            $data2 = $_POST['echo_keyword_list'];
			$rules = array();
            if(isset($data2['keyword'][0]))
            {
                for($i = 0; $i < sizeof($data2['keyword']); ++$i) {
                    if(isset($data2['keyword'][$i]) && $data2['keyword'][$i] != '')
                    {
                        //$index = trim( sanitize_text_field($data2['keyword'][$i]));
                        //$rules[$index] = trim( sanitize_text_field( $data2['link'][$i] ) );
                    }
                }
            }
            //update_option('echo_keyword_list', $rules);
		}
function echo_expand_keyword_rules() {
    //todo
    /*
			$rules = get_option('echo_keyword_list');
			$output = '';
            $cont = 0;
			if (!empty($rules)) {
				foreach ($rules as $request => $value) {  
					$output .= '<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">' . $cont . '</td>
                        <td style="width:45%;text-align:center;vertical-align: middle;"><input type="text" name="echo_keyword_list[keyword][]" value="'.$request.'" required  style="width:100%;"></td>
                        <td style="width:45%;text-align:center;vertical-align: middle;"><input type="url" validator="url" name="echo_keyword_list[link][]" value="'.$value.'" required  style="width:100%;"></td>
					</tr>';
                    $cont++;
				}
			}
            */
            $output = '';
			return $output;
		}
?>