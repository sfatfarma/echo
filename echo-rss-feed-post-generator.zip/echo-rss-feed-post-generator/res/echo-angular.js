angular.module('echsettingsApp', ['ngSanitize'])
.controller('echsettingsController', function($scope) {
    $scope.settings = echo_admin_json;
});