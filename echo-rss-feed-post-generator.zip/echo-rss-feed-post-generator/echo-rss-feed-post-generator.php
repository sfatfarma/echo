<?php
/** 
Plugin Name: Echo RSS Feed Post Generator
Plugin URI: http://codecanyon.net/user/coderevolution/portfolio
Description: This plugin will generate content for you, even in your sleep using RSS feeds.
Author: CodeRevolution
Version: 1.0
Author URI: https://codecanyon.net/user/coderevolution
*/
defined( 'ABSPATH' ) or die();
require "update-checker/plugin-update-checker.php";

@ini_set('safe_mode','Off'); 
@ini_set('max_execution_time', 0);
@ini_set('ignore_user_abort', 1);
@ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
ignore_user_abort(true);
set_time_limit(0);

$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/echo/master/info.json", __FILE__, "echo-rss-feed-post-generator");
add_action('admin_menu', 'echo_register_my_custom_menu_page');
function echo_register_my_custom_menu_page()
{
    add_menu_page('Echo RSS Feed Post Generator', 'Echo RSS Feed Post Generator', 'manage_options', 'echo_admin_settings', 'echo_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('echo_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'echo_admin_settings');
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    if (isset($echo_Main_Settings['echo_enabled']) && $echo_Main_Settings['echo_enabled'] == 'on') {
        //add_submenu_page('echo_admin_settings', 'Activity & Logging', 'Activity & Logging', 'manage_options', 'echo_logs', 'echo_logs');
    }
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'echo_add_settings_link');
function echo_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=echo_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
add_action('add_meta_boxes', 'echo_add_meta_box');
function echo_add_meta_box()
{
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    if (isset($echo_Main_Settings['echo_enabled']) && $echo_Main_Settings['echo_enabled'] === 'on') {
        if (isset($echo_Main_Settings['enable_metabox']) && $echo_Main_Settings['enable_metabox'] == 'on') {
            add_meta_box('echo_meta_box_function_add', 'Echo Auto Generated Post Information', 'echo_meta_box_function', 'post', 'advanced', 'default');
            add_meta_box('echo_meta_box_function_add', 'Echo Auto Generated Post Information', 'echo_meta_box_function', 'page', 'advanced', 'default');
        }
    }
}
function echo_meta_box_function($post)
{
    //$post_creator_last_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
    $post_creator_last_updated = 'today';
    $post_item_id              = '0';
    if (isset($post_item_id) && $post_item_id != '') {
        $ech = '<table><tr><td><b>Item Last Updated:</b></td><td>&nbsp;' . $post_creator_last_updated . '</td></tr>'; 
        $ech .= '</table><br/>';
    } else {
        $ech = 'This is not an automatically generated post.';
    }
    echo $ech;
}

function echo_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
add_filter('cron_schedules', 'echo_add_cron_schedule');
function echo_add_cron_schedule($schedules)
{
    $schedules['echo_cron'] = array(
        'interval' => 3600,
        'display' => __('Echo Cron')
    );
    $schedules['weekly']     = array(
        'interval' => 604800,
        'display' => __('Once Weekly')
    );
    $schedules['monthly']    = array(
        'interval' => 2592000,
        'display' => __('Once Monthly')
    );
    return $schedules;
}
function echo_auto_clear_log() {
    if(file_exists(WP_CONTENT_DIR . '/echo_info.log'))
    {
        unlink(WP_CONTENT_DIR . '/echo_info.log');
    }
}

register_deactivation_hook(__FILE__, 'echo_my_deactivation');
function echo_my_deactivation() {
	wp_clear_scheduled_hook('echoaction');
    wp_clear_scheduled_hook('echoactionclear');
    $running = array();
    update_option('echo_running_list', $running);
    update_option('echo_auto_running_list', $running);
}
add_action('echoaction', 'echo_cron');
add_action('echoactionclear', 'echo_auto_clear_log' );
if(is_admin())
{
    echo_cron_schedule();
}
function echo_cron_schedule()
{
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    if (isset($echo_Main_Settings['echo_enabled']) && $echo_Main_Settings['echo_enabled'] === 'on') {      
        if (!wp_next_scheduled('echoaction')) {
            $rez = wp_schedule_event(time(), 'echo_cron', 'echoaction');
            if($rez === FALSE)
            {
                echo_log_to_file ('[Scheduler] Failed to schedule echoaction to echo_cron!', '0', '1');
            }
        }
        
        if(isset($echo_Main_Settings['enable_logging']) && $echo_Main_Settings['enable_logging'] === 'on' && isset($echo_Main_Settings['auto_clear_logs']) && $echo_Main_Settings['auto_clear_logs'] !== 'No')
        {
            if (!wp_next_scheduled( 'echoactionclear')) 
            {
                $rez = wp_schedule_event(time(), $echo_Main_Settings['auto_clear_logs'], 'echoactionclear' );
                if($rez === FALSE)
                {
                    echo_log_to_file ('[Scheduler] Failed to schedule echoactionclear to ' . $echo_Main_Settings['auto_clear_logs'] . '!', '0', '1');
                }
                add_option('echo_schedule_time', $echo_Main_Settings['auto_clear_logs']);
            }
            else
            {
                if (!get_option('echo_schedule_time')) {
                    wp_clear_scheduled_hook( 'echoactionclear' );
                    $rez = wp_schedule_event(time(), $echo_Main_Settings['auto_clear_logs'], 'echoactionclear' );
                    add_option('echo_schedule_time', $echo_Main_Settings['auto_clear_logs']);
                    if($rez === FALSE)
                    {
                        echo_log_to_file ('[Scheduler] Failed to schedule echoactionclear to ' . $echo_Main_Settings['auto_clear_logs'] . '!', '0', '1');
                    }
                }
                else
                {
                    $the_time = get_option('echo_schedule_time');
                    if($the_time != $echo_Main_Settings['auto_clear_logs'])
                    {
                        wp_clear_scheduled_hook( 'echoactionclear' );
                        delete_option('echo_schedule_time');
                        $rez = wp_schedule_event(time(), $echo_Main_Settings['auto_clear_logs'], 'echoactionclear' );
                        add_option('echo_schedule_time', $echo_Main_Settings['auto_clear_logs']);
                        if($rez === FALSE)
                        {
                            echo_log_to_file ('[Scheduler] Failed to schedule echoactionclear to ' . $echo_Main_Settings['auto_clear_logs'] . '!', '0', '1');
                        }
                    }
                }
            }
        }
        else
        {
            if (!wp_next_scheduled( 'echoactionclear' )) 
            {
                delete_option('echo_schedule_time');
            }
            else
            {
                wp_clear_scheduled_hook( 'echoactionclear' );
                delete_option('echo_schedule_time');
            }
        }
    }
    else 
    {
        if (wp_next_scheduled('echoaction')) {
            wp_clear_scheduled_hook('echoaction');
        }
        
        if (!wp_next_scheduled( 'echoactionclear' )) 
        {
            delete_option('echo_schedule_time');
        }
        else
        {
            wp_clear_scheduled_hook( 'echoactionclear' );
            delete_option('echo_schedule_time');
        }
    }   
}
function echo_cron()
{
    if (!get_option('echo_rules_list')) {
        $rules = array();
    } else {
        $rules = get_option('echo_rules_list');
    }
    if (!empty($rules)) {
        $cont = 0;
        foreach ($rules as $request => $bundle[]) {
            //todo - auto run rule if it is time
        }
    }
}
function echo_add_ajaxurl()
{
    
    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
function echo_log_to_file ($str, $param, $auto) {
  $echo_Main_Settings = get_option('echo_Main_Settings', false);
  if(isset($echo_Main_Settings['enable_logging']) && $echo_Main_Settings['enable_logging'] == 'on')
  {
    $d = date("j-M-Y H:i:s e");
    error_log("[$d][" . (($auto == '1') ? 'ScheduledRun' : 'ManualRun') . "][ID" . $param . "] " .  $str . "<br/>\r\n", 3, WP_CONTENT_DIR . '/echo_info.log');
  }
}
function echo_delete_all_posts()
{
    $failed = false;
    $number = 0;
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    $query     = array(
        'post_status' => array(
            'publish',
            'draft',
            'pending',
            'trash',
            'private'
        ),
        'post_type' => array(
            'any'
        ),
        'numberposts' => -1
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        //todo - nu lasat post_parent_rule sa nu intre in conflict cu midas
        $index = get_post_meta($post->ID, 'post_parent_rule', true);
        if (isset($index) && $index !== '') {
            $args = array(
                'post_parent' => $post->ID
            );
            $post_attachments = get_children($args);
            if(isset($post_attachments) && !empty($post_attachments)) {
                foreach ($post_attachments as $attachment) {
                    wp_delete_attachment($attachment->ID, true);
                }
            }
            $res = wp_delete_post($post->ID, true);
            if ($res === false) {
                $failed = true;
            }
            else
            {
                $number++;
            }
        }
    }
    if ($failed === true) {
        if(isset($echo_Main_Settings['enable_detailed_logging']))
        {
            echo_log_to_file ('[PostDelete] Failed to delete all posts!', 0, 0);
        }
    } else {
        if(isset($echo_Main_Settings['enable_detailed_logging']))
        {
            echo_log_to_file ('[PostDelete] Successfuly deleted ' . $number . ' posts!', 0, 0);
        }
    }
}
add_action('wp_head', 'echo_add_ajaxurl');
add_action('wp_ajax_echo_my_action', 'echo_my_action_callback');
function echo_my_action_callback()
{
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    $failed       = false;
    $del_id       = $_POST['id'];
    $how          = $_POST['how'];
    $force_delete = true;
    $number = 0;
    if ($how == 'trash') {
        $force_delete = false;
    }
    $query     = array(
        'post_status' => array(
            'publish',
            'draft',
            'pending',
            'trash',
            'private'
        ),
        'post_type' => array(
            'any'
        ),
        'numberposts' => -1
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        $index       = get_post_meta($post->ID, 'post_parent_rule', true);
        if ($index == $del_id) {
            $args = array(
                'post_parent' => $post->ID
            );
            $post_attachments = get_children($args);
            if(isset($post_attachments) && !empty($post_attachments)) {
                foreach ($post_attachments as $attachment) {
                    wp_delete_attachment($attachment->ID, true);
                }
            }
            $res = wp_delete_post($post->ID, $force_delete);
            if ($res === false) {
                $failed = true;
            }
            else
            {
                $number++;
            }
        }
    }
    if ($failed === true) {
        if(isset($echo_Main_Settings['enable_detailed_logging']))
        {
            echo_log_to_file ('[PostDelete] Failed to delete all posts for rule id: ' . $del_id . '!', $del_id, 0);
        }
        echo 'failed';
    } else {
        if(isset($echo_Main_Settings['enable_detailed_logging']))
        {
            echo_log_to_file ('[PostDelete] Successfuly deleted ' . $number . ' posts for rule id: ' . $del_id . ' of type ' . $type . '!', $del_id, 0);
        }
        echo 'ok';
    }
    die();
}
add_action('wp_ajax_echo_run_my_action', 'echo_run_my_action_callback');
function echo_run_my_action_callback()
{
    $run_id = $_POST['id'];
    echo echo_run_rule($run_id, 0);
    die();
}

function echo_get_xml_value($xml, $field)
{
    if (!empty($xml->childNodes)) {
        foreach ($xml->childNodes as $xmlChild) {
            if ($xmlChild->nodeName == $field) {
                return $xmlChild->nodeValue;
            }
        }
    }
    return '';
}

function echo_endswith($string, $test) {
    $strlen = strlen($string);
    $testlen = strlen($test);
    if ($testlen > $strlen) return false;
    return substr_compare($string, $test, $strlen - $testlen, $testlen) === 0;
}

function echo_clearFromList($param, $type)
{
    $running = get_option('echo_running_list');
    $key = array_search(array(
        $param => $type
    ), $running);
    if ($key !== FALSE) {
        unset($running[$key]);
        update_option('echo_running_list', $running);
    }
    else
    {
        echo_log_to_file ('[RunningList][ERROR] Failed to delete key from running list: ' . $param . ' -> ' . $type , $param, $type, 1);
    }
}

function echo_url_handle($href)
{
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    $envatocash_google_key = get_option('envatocash-google-key');
    if (isset($echo_Main_Settings['links_hide']) && $echo_Main_Settings['links_hide'] == 'on') {
        $cloak_urls = true;
    } else {
        $cloak_urls = false;
    }
    if (isset($echo_Main_Settings['apiKey'])) {
        $apiKey = $echo_Main_Settings['apiKey'];
    } else {
        $apiKey = '';
    }
    if ($cloak_urls == true && $apiKey != '') {
        $longUrl  = trim($href);
        $postData = array(
            'longUrl' => $longUrl,
            'key' => $apiKey
        );
        $jsonData = json_encode($postData);
        if($jsonData === FALSE)
        {
            return $href;
        }
        $curlObj  = curl_init();
        if($curlObj === FALSE)
        {
            return $href;
        }
        curl_setopt($curlObj, CURLOPT_TIMEOUT_MS, 600000); //in miliseconds
        curl_setopt($curlObj, CURLOPT_URL, 'https://www.googleapis.com/urlshortener/v1/url?key=' . $apiKey);
        curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlObj, CURLOPT_HEADER, 0);
        curl_setopt($curlObj, CURLOPT_HTTPHEADER, array(
            'Content-type:application/json'
        ));
        curl_setopt($curlObj, CURLOPT_POST, 1);
        curl_setopt($curlObj, CURLOPT_POSTFIELDS, $jsonData);
        $response = curl_exec($curlObj);
        if($response === FALSE)
        {
            curl_close($curlObj);
            return $href;
        }
        $json     = json_decode($response);
        curl_close($curlObj);
        if (!isset($json->id) || $json->id == '') {
            return $href;
        } else {
            return $json->id;
        }
    } else {
        return $href;
    }
}
function echo_run_rule($param, $type = 0, $auto = 1)
{
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', 0);
    @ini_set('ignore_user_abort', 1);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    ignore_user_abort(true);
    set_time_limit(0);
    $posts_inserted = 0;
    $auto_generate_comments = '0';
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    if (isset($echo_Main_Settings['echo_enabled']) && $echo_Main_Settings['echo_enabled'] == 'on') {
        try {
            
        }
        catch (Exception $e) {
            echo_clearFromList($param, $type);
            echo_log_to_file ('Exception thrown ' . $e . '!', $param, $type, $auto);
            return 'fail';
        }
        if(isset($echo_Main_Settings['enable_detailed_logging']))
        {
            echo_log_to_file ('Rule succesfully run! ' . $posts_inserted . ' posts created!', $param, $type, $auto);
        }
        echo_clearFromList($param, $type);
    }
    return 'ok';
}

function echo_addPostMeta($post_id, $post, $param, $type, $envato_username)
{
    //add_post_meta($post_id, 'post_creator_last_updated', $post['market_item_last_updated']);
}

function echo_updatePostMeta($post_id, $post, $param, $type, $envato_username)
{
    //update_post_meta($post_id, 'post_creator_last_updated', $post['market_item_last_updated']);
    
}

function echo_replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    //$the_content = str_replace('%%random_sentence%%', echo_random_sentence_generator(), $the_content);
    
    return $the_content;
}

function echo_replaceContentType6Shortcodes($total, $counter, $the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    //$the_content = str_replace('%%total_item_count%%', $total, $the_content);
    
    return $the_content;
}

function echo_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    //$the_title = str_replace('%%random_sentence%%', echo_random_sentence_generator(), $the_title);
    
    return $the_title;
}

function echo_generate_featured_image($image_url, $post_id)
{
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    if($image_data === FALSE)
    {
        return false;
    }
    $filename = basename($image_url);
    $filename = str_replace('%', '-', $filename);
    $filename = str_replace('#', '-', $filename);
    $filename = str_replace('&', '-', $filename);
    $filename = str_replace('{', '-', $filename);
    $filename = str_replace('}', '-', $filename);
    $filename = str_replace('\\', '-', $filename);
    $filename = str_replace('<', '-', $filename);
    $filename = str_replace('>', '-', $filename);
    $filename = str_replace('*', '-', $filename);
    $filename = str_replace('?', '-', $filename);
    $filename = str_replace('/', '-', $filename);
    $filename = str_replace('$', '-', $filename);
    $filename = str_replace('\'', '-', $filename);
    $filename = str_replace('"', '-', $filename);
    $filename = str_replace(':', '-', $filename);
    $filename = str_replace('@', '-', $filename);
    $filename = str_replace('+', '-', $filename);
    $filename = str_replace('|', '-', $filename);
    $filename = str_replace('=', '-', $filename);
    $filename = str_replace('`', '-', $filename);
    if (wp_mkdir_p($upload_dir['path'] . '/' . $post_id))
        $file = $upload_dir['path'] . '/' . $post_id . '/' . $filename;
    else
        $file = $upload_dir['basedir'] . '/' . $post_id . '/' . $filename;
    $ret = file_put_contents($file, $image_data);
    if($ret === FALSE)
    {
        return false;
    }
    $wp_filetype = wp_check_filetype($filename, null);
    $attachment  = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id   = wp_insert_attachment($attachment, $file, $post_id);
    if($attach_id === 0)
    {
        return false;
    }
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
    $res1        = wp_update_attachment_metadata($attach_id, $attach_data);
    if($res1 === FALSE)
    {
        return false;
    }
    $res2        = set_post_thumbnail($post_id, $attach_id);
    if($res2 === FALSE)
    {
        return false;
    }
    return true;
}

function echo_hour_diff($date1, $date2)
{
    $date1 = new DateTime($date1);
    $date2 = new DateTime($date2);
    
    $number1 = (int) $date1->format('U');
    $number2 = (int) $date2->format('U');
    return ($number1 - $number2) / 60 / 60;
}

function echo_add_hour($date, $hour)
{
    $date1 = new DateTime($date);
    $date1->modify("$hour hours");
    foreach ($date1 as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return $date;
}

function echo_get_date_now($param = 'now')
{
    $date = new DateTime($param);
    foreach ($date as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return '';
}

function echo_create_terms($taxonomy, $parent, $terms_str)
{
    $terms          = explode('/', $terms_str);
    $categories     = array();
    $parent_term_id = $parent;
    foreach ($terms as $term) {
        $res = term_exists($term, $taxonomy);
        if ($res != NULL && $res != 0 && count($res) > 0 && isset($res['term_id'])) {
            $parent_term_id = $res['term_id'];
            $categories[]   = $parent_term_id;
        } else {
            $new_term = wp_insert_term($term, $taxonomy, array(
                'parent' => $parent_term_id
            ));
            if ($new_term != NULL && $new_term != 0 && count($new_term) > 0 && isset($new_term['term_id'])) {
                $parent_term_id = $new_term['term_id'];
                $categories[]   = $parent_term_id;
            }
        }
    }
    
    return $categories;
}

function echo_getExcerpt($the_content)
{
    $preview = wp_trim_words($the_content, 55);
    $preview = strip_tags($preview);
    return $preview;
}

function echo_getPlainContent($the_content)
{
    $preview = wp_trim_words($the_content, 999999);
    $preview = strip_tags($preview);
    return $preview;
}
function echo_getItemImageOrMedia($marketplace, $json, $ref_user, $disable_style = false)
{
    $preview = '';
    //todo
    return $preview;
}

function echo_getSeeMoreButton($json, $ref_user)
{
    $link = '';
    //todo
    return $link;
}

function echo_getVideoPreview($json, $ref_user)
{
    $link = '';
    //todo
    return $link;
}
function echo_getVideoPreviewButton($json, $ref_user)
{
    $link = '';
    //todo
    return $link;
}

function echo_getBuyNowButton($json, $ref_user)
{
    $link = '';
    //todo
    return $link;
}
function echo_check_http_header_error($str)
{
    if(strpos($str, '404 Not Found') !== FALSE || strpos($str, '400 Bad Request') !== FALSE || strpos($str, '401 Unauthorized') !== FALSE || strpos($str, '402 Payment Required') !== FALSE || strpos($str, '403 Forbidden') !== FALSE || strpos($str, '405 Method Not Allowed') !== FALSE || strpos($str, '406 Not Acceptable') !== FALSE || strpos($str, '407 Proxy Authentication Required') !== FALSE || strpos($str, '408 Request Time-out') !== FALSE || strpos($str, '409 Conflict') !== FALSE || strpos($str, '410 Gone') !== FALSE || strpos($str, '411 Length Required') !== FALSE || strpos($str, '412 Precondition Failed') !== FALSE || strpos($str, '413 Payload Too Large') !== FALSE || strpos($str, '414 URI Too Long') !== FALSE || strpos($str, '415 Unsupported Media Type') !== FALSE || strpos($str, '416 Range Not Satisfiable') !== FALSE || strpos($str, '417 Expectation Failed') !== FALSE || strpos($str, '418 I\'m a teapot') !== FALSE || strpos($str, '421 Misdirected Request') !== FALSE || strpos($str, '422 Unprocessable Entity') !== FALSE || strpos($str, '423 Locked') !== FALSE || strpos($str, '424 Failed Dependency') !== FALSE || strpos($str, '426 Upgrade Required') !== FALSE || strpos($str, '428 Precondition Required') !== FALSE || strpos($str, '429 Too Many Requests') !== FALSE || strpos($str, '431 Request Header Fields Too Large') !== FALSE || strpos($str, '451 Unavailable For Legal Reasons') !== FALSE)
    {
        return true;
    }
    if(strpos($str, '500 Internal Server Error') !== FALSE || strpos($str, '501 Not Implemented') !== FALSE || strpos($str, '502 Bad Gateway') !== FALSE || strpos($str, '503 Service Unavailable') !== FALSE || strpos($str, '504 Gateway Time-out') !== FALSE || strpos($str, '505 HTTP Version Not Supported') !== FALSE || strpos($str, '506 Variant Also Negotiates') !== FALSE || strpos($str, '507 Insufficient Storage') !== FALSE || strpos($str, '508 Loop Detected') !== FALSE || strpos($str, '510 Not Extended') !== FALSE || strpos($str, '511 Network Authentication Required') !== FALSE)
    {
        return true;
    }
    return false;
}
function echo_getScreenshotsButton($json, $ref_user)
{
    $link = '';
    //todo
    return $link;
}
function echo_getRotatingPreviewButton($json, $ref_user)
{
    $link = '';
    //todo
    return $link;
}

add_action('admin_head', 'echo_my_custom_fonts');

function echo_my_custom_fonts() {
  echo '<style>#taxonomy-echo_post{width:100px;}}</style>';
}

add_action( 'init', 'echo_create_taxonomy', 0 );

function echo_create_taxonomy() {
	$labels = array(
		'name'                       => _x( 'echo Post Types', 'taxonomy general name', 'textdomain' ),
		'singular_name'              => _x( 'echo Post Type', 'taxonomy singular name', 'textdomain' ),
		'search_items'               => __( 'Search echo Post Types', 'textdomain' ),
		'popular_items'              => __( 'Popular echo Post Types', 'textdomain' ),
		'all_items'                  => __( 'All echo Post Types', 'textdomain' ),
		'parent_item'                => null,
		'parent_item_colon'          => null,
		'edit_item'                  => __( 'Edit echo Post Types', 'textdomain' ),
		'update_item'                => __( 'Update echo Post Types', 'textdomain' ),
		'add_new_item'               => __( 'Add New echo Post Type', 'textdomain' ),
		'new_item_name'              => __( 'New echo Post Type Name', 'textdomain' ),
		'separate_items_with_commas' => __( 'Separate echo Posts Type with commas', 'textdomain' ),
		'add_or_remove_items'        => __( 'Add or remove echo Posts Type', 'textdomain' ),
		'choose_from_most_used'      => __( 'Choose from the most used echo Post Types', 'textdomain' ),
		'not_found'                  => __( 'No echo Post Types found.', 'textdomain' ),
		'menu_name'                  => __( 'echo Post Types', 'textdomain' ),
	);

	$args = array(
		'hierarchical'          => false,
        'description'           => 'echo Post Type',
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => array( 'slug' => 'echo_post' ),
	);

	register_taxonomy( 'echo_post', array('post', 'page'), $args );
}

function echo_getLiveLink($marketplace, $json, $ref_user)
{
    $preview = '';
    //todo
    return $preview;
}

function echo_getIntro($marketplace, $json, $ref_user)
{
    //todo
    $preview = '';
    return $preview;
}

function echo_getThumbnail($marketplace, $json, $ref_user)
{
    $media     = echo_getItemImageOrMedia($marketplace, $json, $ref_user, true);
    
    $preview   = '<ul class="echo_enlarge"><li><img src="' . $json['thumbnail'] . '" alt="thumbnail" /><span>' . $media . '<a href="' . $json['url'] . '?ref=' . $ref_user . '" target="_blank" style="text-decoration:none;"><table cellspacing="0" cellpadding="0" style="margin-bottom:0px;border: none;"><tr><td style="border: none;"><div style="color:white;font-size: 1.5em;text-align:left;"><b>' . $json['item'] . '</b></div></td><td style="border: none;vertical-align:middle;text-align:center;width:15%;" rowspan="3"><div style="color:white;"><div style="float:left;font-size: 2.3em;"><b>$' . str_replace(".00", "", $json['cost']) . '</div></b></div></td></tr><tr><td style="border: none;"><div style="color:#111;text-align:left;">by: ' . $json['user'] . '</div></td></tr><tr><td style="border: none;"><div style="color:#aaa;text-align:left;">' . $json['category'] . '</div></td></tr></table></a></span></li></ul>';
    return $preview;
}

register_activation_hook(__FILE__, 'echo_activation_callback');
function echo_activation_callback($defaults = FALSE)
{
    if (!get_option('echo_Main_Settings') || $defaults === TRUE) {
        $echo_Main_Settings = array(
            'echo_enabled' => 'on'
            
        );
        if($defaults === FALSE)
        {
            add_option('echo_Main_Settings', $echo_Main_Settings);
        }
        else
        {
            update_option('echo_Main_Settings', $echo_Main_Settings);
        }
    }
}

register_activation_hook(__FILE__, 'echo_check_version');
function echo_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.0';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
    
    //alter deprecated.php - remove hardcoded timeout
    $file2 = ABSPATH . '/wp-includes/deprecated.php';
    if (file_exists($file2)) {
        $text2 = file_get_contents($file2);
    } else {
        $text2 = "";
    }
    if($text2 != "" && $text2 !== FALSE)
    {
        if (strpos($text2, '@set_time_limit( 60 );') !== false) {
            $text2 = str_replace('@set_time_limit( 60 );', '//@set_time_limit(60);', $text2);
            $rez = file_put_contents($file2, $text2);
            if($rez === FALSE)
            {
                echo_log_to_file("[CRITICAL] Failed to update deprecated.php!", '0', 7, '1');
            }
        }
    }
    //same for wp-config
    $file3 = ABSPATH . '/wp-config.php';
    if (file_exists($file3)) {
        $text3 = file_get_contents($file3);
    } else {
        $text3 = "";
    }
    if($text3 != "" && $text3 !== FALSE)
    {
        if (strpos($text3, '@set_time_limit(0);') === FALSE) {
            $text3 = '@set_time_limit(0);';
            $rez = file_put_contents($file3, $text3, FILE_APPEND);
            if($rez === FALSE)
            {
                echo_log_to_file("[CRITICAL] Failed to update wp-config.php!", '0', 7, '1');
            }
        }
    }
}

add_action('admin_init', 'echo_register_mysettings');
function echo_register_mysettings()
{
    register_setting('echo_option_group', 'echo_Main_Settings');
}

function echo_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function echo_get_file_url($url)
{
    return echo_get_plugin_url() . '/' . $url;
}

add_action('admin_enqueue_scripts', 'echo_admin_load_files');
function echo_admin_load_files()
{
    wp_register_style('echo-browser-style', plugins_url('styles/echo-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('echo-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('echo-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('echo-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('echo-settings-app', plugins_url('res/echo-angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('wp_enqueue_scripts', 'echo_wp_load_files');
function echo_wp_load_files()
{
    wp_enqueue_style( 'echo_jplayer_css', plugins_url('res/jplayer/jplayer.css', __FILE__) );
    wp_enqueue_style( 'echo_fancybox_css', plugins_url('res/fancybox/jquery.fancybox.css', __FILE__) );
    wp_enqueue_script('echo_fancybox', plugins_url('res/fancybox/jquery.fancybox.pack.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('echo_fancybox_init', plugins_url('res/fancybox_init.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('echo_jplayer', plugins_url('res/jplayer/jplayer.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_style( 'echo_thumbnail_css', plugins_url('styles/echo-thumbnail.css', __FILE__) );
}

function echo_random_sentence_generator($first = true)
{
    $echo_Main_Settings = get_option('echo_Main_Settings', false);
    if($first == false)
    {
        $r_sentences = $echo_Main_Settings['sentence_list2'];
    }
    else
    {
        $r_sentences = $echo_Main_Settings['sentence_list'];
    }
    $r_variables = $echo_Main_Settings['variable_list'];
    $r_sentences = trim($r_sentences);
    $r_variables = trim($r_variables, ';');
    $r_variables = trim($r_variables);
    $r_sentences = str_replace("\r\n", "\n", $r_sentences);
    $r_sentences = str_replace("\r", "\n", $r_sentences);
    $r_sentences = explode("\n", $r_sentences);
    $r_variables = str_replace("\r\n", "\n", $r_variables);
    $r_variables = str_replace("\r", "\n", $r_variables);
    $r_variables = explode("\n", $r_variables);
    $r_vars = array();
    for($x=0; $x < count($r_variables); $x++){
        $var = explode("=>", trim($r_variables[$x]));
        if(isset($var[1]))
        {
            $key = strtolower(trim($var[0]));
            $words = explode(";", trim($var[1]));
            $r_vars[$key] = $words;
        }
    }
    $max_s = count($r_sentences)-1;
    $rand_s = rand(0, $max_s);
    $sentence = $r_sentences[$rand_s];
    $sentence = str_replace(' ,', ',', ucfirst(echo_replace_words($sentence, $r_vars)));
    $sentence = str_replace(' .', '.', $sentence);
    $sentence = str_replace(' !', '!', $sentence);
    $sentence = str_replace(' ?', '?', $sentence);
    $sentence = trim($sentence);
    return $sentence;
}

function echo_get_word($key, $r_vars){
    if (isset($r_vars[$key])){
 
        $words = $r_vars[$key];
        $w_max = count($words)-1;
        $w_rand = rand(0, $w_max);
        return echo_replace_words(trim($words[$w_rand]), $r_vars);
    }
    else {
        return "";
    }
 
}

function echo_replace_words($sentence, $r_vars){
 
    if (str_replace('%', '', $sentence) == $sentence)
        return $sentence;
 
    $words = explode(" ", $sentence);
 
    $new_sentence = array();
    for($w=0; $w < count($words); $w++){
 
        $word = trim($words[$w]);
 
        if ($word != ''){
            if (preg_match('/^%(.*)$/', $word, $m)){
                $varkey = trim($m[1]);
                $new_sentence[] = echo_get_word($varkey, $r_vars);
            }
            else {
                $new_sentence[] = $word;
            }
        }
    }
    return implode(" ", $new_sentence);    
}

require(dirname(__FILE__) . "/res/echo-main.php");
require(dirname(__FILE__) . "/res/autoloader.php");
?>